service.subtitles.subdivx
=========================

Subdivx.com subtitle service plugin for Kodi/XBMC versions ranging

- From XBMC Gotham (v14) up to Kodi Leia (v18): Versions 0.3.x (in maintenance mode) -- See `gotham` branch
- From Kodi Matrix (v19) and later: Versions starting with 0.4.0 -- `master` branch

Ported from the pre-Gotham version. All the credit to its authors.
